# Emma OTP Boss (Android starter project)

This is a lightweight Android Studio project that opens the free public-number directory at ASMS inside an app-branded WebView.

## What it does
- App name: Emma OTP Boss
- Opens the ASMS free public phone-number directory
- Lets the visitor choose a listed number and view its live public inbox on the provider site
- Back, refresh, and home controls

## Important provider limitation
ASMS documents free shared numbers as a public website feature. Its documented REST API for programmatic ordering and SMS polling is a paid wallet product; it is not a free API for the public number pool. This starter therefore does not pretend to offer a private inbox or an API-backed free number allocator.

Free shared inboxes are visible to everyone. Do not use them for banking, account recovery, personal accounts, or messages containing private information. Some services reject shared numbers.

## Build an APK
1. Open this folder in Android Studio (Giraffe or newer).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Project details
- Package: `com.emma.otpboss`
- Minimum Android: 6.0 (API 23)
- Target SDK: 35
- No API key is embedded in the app.
